---
name: case-report-writer
description: Transform scattered clinical materials (history, labs, imaging, pathology, treatment course, follow-up) into a publication-ready medical case report manuscript compliant with reporting guidelines — CARE 2013 by default, SCARE 2023 for surgical cases. Use when writing a case report or case study for journal submission (in English or Chinese), when the user mentions CARE/SCARE reporting guidelines, or when asked to organize raw patient data into a structured manuscript. Supports mandatory timeline tables, literature-grounded discussion, de-identification, and a guideline compliance self-check.
---

# Case Report Writer

Turn scattered clinical materials into a guideline-compliant, submission-ready case report manuscript.

## Core principles (non-negotiable)

1. **Fidelity to source data.** Every value, date, dose, and conclusion must match the user's materials. Never invent or "fill in" clinical data. Mark missing items explicitly and ask the user.
2. **De-identification.** No name, initials, MRN/inpatient number, ID number, phone, exact address, or day-precision identifiable dates in the output. Convert dates to relative time ("hospital day 3") unless the journal requires otherwise. Rare disease + occupation + region combinations can indirectly identify a patient — generalize further when in doubt.
3. **Framework before prose.** Extract and confirm the structured data inventory with the user before drafting anything.
4. **No fabricated references.** Use whatever literature-search tools the environment offers (PubMed, web search). If none are available, leave `[citation needed]` placeholders and ask the user to supply sources. Never invent a reference entry.

## Workflow

### Step 1 — Intake and format calibration

Confirm, asking only what is unknown (one key question at a time):

- Target journal, or at least: manuscript language (Chinese / English) and output format (Markdown by default; .docx when the environment has document tooling).
- The case's novelty angle: rare disease, atypical presentation, new therapy, unexpected outcome, diagnostic pitfall, etc.
- Whether written informed consent for publication has been obtained.

If the user supplies published example articles as standing format references: read them **before drafting** and distill a short style note — section order and headings, abstract structure, citation style, tense/voice conventions, table/figure habits, word counts. Save the note as `references/journal-style-<name>.md` inside this skill, link it from the section list below, and follow it throughout.

### Step 2 — Structured extraction

Extract from the materials and present back to the user for confirmation:

- Demographics (de-identified): age, sex, occupation if relevant
- Chief complaint and present illness with symptom timeline
- Past, family, and psychosocial history (if relevant)
- Physical exam: positive and pertinent negative findings
- Investigations: list each as **date + item + value/conclusion + reference range**
- Diagnosis and differential diagnoses, with the evidence that excluded each
- Interventions: drug (dose, route, course), surgery, other — including adjustments and their reasons
- Follow-up: time points, outcomes, adverse events

Flag contradictions between sources and gaps (e.g., missing follow-up) and resolve them with the user before drafting.

### Step 3 — Pick the reporting guideline

- Default: **CARE 2013** (13 items) — read [references/care-2013-checklist.md](references/care-2013-checklist.md).
- Surgical case (an operation or interventional procedure is the focus): **SCARE 2023** — read [references/scare-2023-checklist.md](references/scare-2023-checklist.md). Watch the SCARE extras: highlights, the guideline-citation sentence in the introduction, operator/setting details, Clavien–Dindo grading of complications.
- If the target journal mandates a guideline or its own checklist, the journal's requirement wins.

### Step 4 — Draft the manuscript

CARE section order: Title → Keywords → Abstract → Introduction → Patient information → Clinical findings → Timeline → Diagnostic assessment → Therapeutic intervention → Follow-up and outcomes → Discussion → Patient perspective → Informed consent.

- Always include a **timeline table** (date / event / intervention / outcome).
- Discussion is four moves: key finding summary → comparison with published cases → mechanism or clinical implication → limitations + take-away lessons. Keep the literature in service of the case; do not let the discussion become a mini-review.
- Read [references/writing-guide.md](references/writing-guide.md) before drafting: per-section style, tense rules, de-identification checklist, and common rejection reasons.
- A fill-in skeleton is available at [assets/manuscript-template.md](assets/manuscript-template.md).

### Step 5 — Compliance self-check

Re-check the draft against the chosen checklist item by item. Deliver a compliance table (✅ covered / ⚠️ partial / ❌ missing, each with a one-line note) together with the manuscript, and ask the user whether to fill any ❌ items.

### Step 6 — Deliver

- Present the manuscript and self-check table in conversation first; export only after user confirmation.
- Default export: Markdown file. When the environment offers Word tooling (docx skill/plugin or python-docx), produce a `.docx` named `case-report-<topic>-<date>.docx`.
- Close with reminders: insert de-identified figures, verify the target journal's word limits, and confirm the consent statement reflects reality.

## Output contract

Standard deliverables per task: the manuscript, the compliance checklist, and (when literature search was possible) a verified reference list. Never deliver a manuscript whose underlying data the user has not confirmed.
