# [Diagnosis/phenomenon] + [distinctive point]: a case report
<!-- Title formula: core diagnosis or phenomenon + distinctive point + "case report" -->

**Keywords:** [keyword 1]; [keyword 2]; [keyword 3]; case report
<!-- 2–5 keywords, including "case report" -->

## Abstract
<!-- Four elements: what is unique → main concerns and findings → diagnoses/interventions/outcomes → take-away lessons. Draft early, finalize last. -->

**Background:** [What is unique about this case and what it adds to the literature.]

**Case presentation:** [Main concerns and important clinical findings; primary diagnoses, interventions, and outcomes.]

**Conclusions:** [One or two take-away lessons.]

## Introduction
<!-- Disease background (with citations) → why this case is unique → aim of the report. 1–2 paragraphs; do not retell the case. -->

## Case presentation
<!-- Chronological order, consistent with the timeline table. -->

### Patient information
[De-identified demographics; chief complaint and present illness; past, family, and psychosocial history; relevant past interventions and outcomes.]

### Clinical findings
[Significant physical examination and important clinical findings, including pertinent negatives.]

### Timeline

| Date / Day | Event | Intervention | Outcome |
|------------|-------|--------------|---------|
| [day 0]    | [onset / admission] | — | — |
| [day N]    | [test / event] | [treatment] | [response] |

### Diagnostic assessment
[Methods with values and reference ranges; diagnostic challenges; differential diagnoses with the evidence excluding each; prognostic characteristics if applicable.]

### Therapeutic intervention
[Types; dosage, strength, duration, route; changes and their rationale.]

### Follow-up and outcomes
[Time points; clinician- and patient-assessed outcomes; follow-up test results; adherence and tolerability; adverse events — or "no adverse events were observed".]

## Discussion
<!-- Four moves: key findings → comparison with the literature → mechanism/clinical implication → limitations and take-away lessons. Literature serves the case. -->

## Patient perspective
[The patient's own account, or a note that it could not be obtained and why.]

## Declarations

**Informed consent:** Written informed consent was obtained from the patient for publication of this case report and any accompanying images.
<!-- For Chinese-language journals, replace with the journal's standard consent statement. -->

**Acknowledgements / Funding / Conflicts of interest:** [as applicable]

## References
<!-- List only references actually retrieved or supplied by the user; leave [citation needed] where a source is missing. Never fabricate. -->
