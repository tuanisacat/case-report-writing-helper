# Writing Guide — Section by Section

Read this before drafting. Applies to both English- and Chinese-language manuscripts; rules that differ by language are marked.

## Voice and style

- Objective, concise, declarative. Never exaggerate: claims like "the first ever reported" require literature proof; otherwise write "rare".
- Numbers carry units and reference ranges. Quote imaging and pathology conclusions faithfully — never paraphrase them into colloquial language.
- Tense (English manuscripts): case presentation in the past tense; general truths in the discussion in the present tense. Chinese manuscripts have no tense constraint.
- Spell out abbreviations at first use, e.g., "diffuse large B-cell lymphoma (DLBCL)". For Chinese manuscripts, give the full Chinese term followed by the English abbreviation in parentheses; use standardized terminology (China National Committee for Terms in Sciences and Technologies).
- A case report is a **narrative**: consistent prose style across sections, every conclusion showing its rationale.

## De-identification checklist

Run through this before delivery:

- [ ] No name, initials, MRN/inpatient number, ID number, phone number
- [ ] No exact address (province/city level only if epidemiologically relevant)
- [ ] Dates: keep the month or convert to relative time ("postoperative day 5"); avoid full dates that allow re-identification — unless the target journal (e.g., SCARE-based ones) requires full dates, in which case confirm with the user
- [ ] Figures: remind the user to crop DICOM overlays and any face/tattoo-identifying features
- [ ] Rare disease + occupation + region can identify indirectly — generalize further when in doubt

## Section notes

### Title and abstract
- Title formula: `<diagnosis/phenomenon> + <distinctive point>: a case report`. For Chinese titles, keep to about 25 characters and use the journal's standard one-case wording.
- Draft the abstract early, but **revise it last** so it matches the final body data exactly.

### Introduction
- Arc: disease background (1–2 sentences, cited) → why this case is unique (rarity, atypicality, new evidence) → purpose of the report.
- Do not retell the case here.

### Case presentation (Patient information → Follow-up)
- Chronological order, consistent with the timeline table.
- When labs are numerous, use a table and let the prose point out only the key abnormal values.
- Imaging and pathology: describe, then quote the original conclusion. Use figure placeholders ("Figure 1. …"; for Chinese journals, the journal's figure-label convention) and remind the user to insert de-identified originals.
- Differential diagnoses must state the **excluding evidence** (which test ruled out what) — reviewers look for this.

### Discussion
Four moves:
1. Key findings of this case (1–2 sentences, no retelling).
2. Comparison with the literature: how many similar cases have been reported, and how this one agrees or differs (search needed — see below).
3. Mechanism or clinical implication: what this case teaches about diagnosis or management.
4. Limitations + take-away lessons.

Literature rules:
- If the environment has search tools (PubMed plugin, web search), use them — query pattern: `disease + key feature + case report`.
- If not, leave `[citation needed]` placeholders and ask the user for sources.
- **Never fabricate a reference.** Every cited entry must come from an actual search result or the user's materials.
- Keep the literature in service of the case; the discussion is not a mini-review.

### Patient perspective and informed consent
- Patient perspective: if the user can supply the patient's own words, shape a short first-person paragraph; otherwise state that it could not be obtained, and why.
- Consent: always ask whether written consent was obtained, and write the statement truthfully — the standard English sentence is in `care-2013-checklist.md` (item 13); for Chinese journals, use the journal's standard consent statement. If consent has not yet been obtained, remind the user it is mandatory before submission.

## Common rejection reasons (avoid while writing)

1. Novelty does not hold — many similar reports already exist → position the incremental value honestly in the discussion.
2. Incomplete data — missing follow-up or key tests → flag during structured extraction; never gloss over.
3. Timeline missing or muddled → the timeline table is mandatory.
4. Discussion becomes a review → keep it anchored to this case.
5. Patient identifiable → run the de-identification checklist.
6. Missing consent statement → CARE item 13 is required.
7. Inconsistency between abstract, tables, and body → revise the abstract last.

## Size reference

- Typical body: 1500–2500 words for English manuscripts, or roughly 1200–2000 characters of main text for Chinese manuscripts; abstract 150–350 words; 10–35 references.
- When the user names a target journal, its instructions for authors override these ranges — remind the user to verify the latest requirements.
