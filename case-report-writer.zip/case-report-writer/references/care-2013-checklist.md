# CARE 2013 Checklist — 13 Items

Source: Gagnier JJ, Kienle G, Altman DG, Moher D, Sox H, Riley D; CARE Group. *The CARE guidelines: consensus-based clinical case reporting guideline development.* J Clin Epidemiol / J Med Case Rep, 2013. Official site: https://www.care-statement.org/checklist (official translations available). Indexed by the EQUATOR Network.

**The narrative:** A case report tells a story in a narrative format that includes the presenting concerns, clinical findings, diagnoses, interventions, outcomes (including adverse events) and follow-up, with a discussion of the rationale for any conclusions and take-away messages.

## Item-by-item requirements

### 1. Title
- The diagnosis or intervention of primary focus followed by the words "case report".
- Pattern: `<diagnosis/intervention> + <distinctive point>: a case report`. For Chinese-language journals, use the journal's standard one-case title wording (the Chinese equivalent of "case report").

### 2. Key Words
- 2 to 5 key words identifying the diagnoses or interventions, including "case report".

### 3. Abstract
Structured or unstructured; no references; four elements (use subheadings for a structured abstract):
- 3a Introduction — what is unique about this case and what it adds to the scientific literature.
- 3b The patient's main concerns and important clinical findings.
- 3c The primary diagnoses, interventions, and outcomes.
- 3d Conclusion — one or more "take-away" lessons.

### 4. Introduction
- Briefly summarize why this case is unique, with medical literature references; end with the aim of the report.
- Do not retell case details here.

### 5. Patient Information
- De-identified patient specific information.
- Primary concerns and symptoms of the patient.
- Medical, family, and psychosocial history including relevant genetic information.
- Relevant past interventions and their outcomes.

### 6. Clinical Findings
- Significant physical examination (PE) and important clinical findings — positives and pertinent negatives.

### 7. Timeline
- Historical and current information from this episode of care organized as a timeline — **figure or table** (date or care-day, event, intervention, outcome). Mandatory, never omit.

### 8. Diagnostic Assessment
- Diagnostic methods (PE, laboratory testing with values and reference ranges, imaging, surveys).
- Diagnostic challenges (e.g., access, financial, cultural), where present.
- Diagnosis, including other diagnoses considered and the evidence that excluded each.
- Prognostic characteristics when applicable (e.g., tumour staging).

### 9. Therapeutic Intervention
- Types of intervention (pharmacologic, surgical, preventive, self-care).
- Administration of intervention (dosage, strength, duration, route).
- Changes in interventions with explanations.

### 10. Follow-up and Outcomes
- Clinician- and patient-assessed outcomes if available.
- Important follow-up diagnostic and other test results (date + value).
- Intervention adherence and tolerability — and how these were assessed.
- Adverse and unanticipated events; if none, state explicitly that no adverse events were observed.

### 11. Discussion
- Strengths and limitations in the management of this case.
- Discussion of the relevant medical literature: how this case compares with published ones.
- The rationale for the conclusions.
- The primary take-away lessons (without references) in a one-paragraph conclusion.

### 12. Patient Perspective
- The patient should share their perspective on the treatment(s) received (one or two short paragraphs); if unobtainable, state so with the reason.

### 13. Informed Consent
- State whether the patient gave informed consent for publication; most journals require written consent.
- Standard English phrasing: "Written informed consent was obtained from the patient for publication of this case report and any accompanying images." For Chinese-language journals, use the journal's standard consent statement.

## How to self-check

Go through the 13 items against the finished draft and mark each:
- ✅ covered
- ⚠️ partial — note what is missing
- ❌ missing — note why, or request the data from the user

Deliver the checklist together with the manuscript. Many journals require a completed checklist with page numbers at submission.

## Extensions

- **SCARE 2023** — surgical case reports (see `scare-2023-checklist.md`).
- **CARE-radiology** — radiological case reports (*BMJ Evidence-Based Medicine*, 2024).
- Other specialty extensions exist (e.g., HOM-CASE for homeopathy, TCM adaptations). When the user names a specialty journal, check whether it mandates an extension.
