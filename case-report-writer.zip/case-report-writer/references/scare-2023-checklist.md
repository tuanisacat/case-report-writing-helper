# SCARE 2023 Checklist — Surgical Case Reports (18 Topics)

Source: Sohrabi C, Mathew G, Maria N, Kerwan A, Franchi T, Agha RA. *The SCARE 2023 guideline: updating consensus Surgical CAse REport (SCARE) guidelines.* Int J Surg. 2023;109(5):1136–1140. PMID: 37013953. Site: https://www.scareguideline.com

Use SCARE instead of CARE when an operation or interventional procedure is the focus of the report. Built via Delphi consensus (44/54 invited experts; 36 items retained). Journals endorsing SCARE usually require the completed checklist uploaded with page numbers **and** the guideline cited in the manuscript (see topic 6).

## Topics

1. **Title** — "case report" must appear in the title; concise; highlight the area of focus (presentation, patient population, diagnosis, surgical intervention, or outcome).
2. **Key words** — 3–6 keywords identifying what is covered (patient population, diagnosis, or intervention); include "case report".
3. **Highlights** — 3–5 bullet points capturing the novel findings: brief background, key results, clinical relevance, and any validation performed. Required by most surgical journals.
4. **Abstract** — structured, four headings:
   - 4a Introduction and importance — what is currently known; what is important, unique, or educational about the case; what it adds to the surgical literature.
   - 4b Presentation of case — presenting complaint(s), clinical and demographic details, the patient's main ideas/concerns/expectations, clinical findings, investigations, main differentials, diagnosis, rationale for the intervention, outcome.
   - 4c Clinical discussion — the findings in relation to current knowledge.
   - 4d Conclusion — relevance and impact of the report; **at least three** take-away lessons or implications for practice.
5. **Introduction**
   - 5a Background — area of focus and relevant contextual knowledge.
   - 5b Rationale — how the case differs from the literature; why it is important to report (rare? specific healthcare setting, population, or country?).
   - 5c Guidelines and literature — reference relevant surgical literature and current standards of care (government, national, or international guidelines).
6. **Guideline citation** — end the introduction with the mandatory sentence:
   > "This case report has been reported in line with the SCARE Criteria [cite Sohrabi 2023]."
7. **Timeline** — sequence of events leading up to presentation; report any delays from presentation to diagnosis and/or intervention; illustrate with a table or figure; use standardized units of time and dates.
8. **Patient information**
   - 8a De-identified demographics (age, sex, ethnicity, occupation; where relevant: BMI, hand dominance, income, education, marital status).
   - 8b Presentation — complaint(s); collateral history if relevant; how the patient presented (self, ambulance, referral); where (outpatient clinic, hospital).
   - 8c Past medical and surgical history — prior admissions, interventions, and outcomes.
   - 8d Drug history and allergies — acute, repeat, and discontinued medications; contraindications to restarting regular medicines (e.g., bleeding risk); allergies and adverse reactions.
   - 8e Family history (first-degree relatives, inheritable conditions); social history (smoking, alcohol, recreational drugs, level of independence, carers, driving, accommodation); focused review of systems.
9. **Clinical findings** — general and significant findings on initial inspection and physical examination.
10. **Diagnostic assessment and interpretation**
    - 10a Methods — bedside (urinalysis, ECG, echocardiography), laboratory, imaging (ultrasound, X-ray, CT/MRI/PET), invasive (endoscopy, biopsy).
    - 10b Diagnostic challenges (access, financial, cultural) and how they were overcome.
    - 10c Diagnostic reasoning — differentials considered, why, and how each was excluded.
    - 10d Prognostic characteristics where applicable (e.g., tumour staging) and how performed.
11. **Intervention**
    - 11a Preoperative optimization — lifestyle, medical (medication review, pre-existing conditions), procedural (nil by mouth, enema), other (psychological support).
    - 11b Types of intervention (pharmacological, surgical, physiotherapy, psychological, preventative) and concurrent treatments (antibiotics, analgesia, antiemetics, VTE prophylaxis); **state manufacturer and model of medical devices**.
    - 11c Specifics — rationale, how it was performed, time to intervention, anaesthesia, patient position, skin preparation, equipment, sutures, devices, surgical stage; postoperative instructions (drain duration, suture removal); degree of novelty (e.g., "first in human"); for drugs: formulation, dosage, strength, route, duration.
    - 11d Operator details — experience and learning-curve position, prior training, specialization; setting of intervention (hospital type, centre experience, cross-specialty or hybrid collaboration).
    - 11e Deviation from the initial management plan, with rationale (e.g., laparoscopic converted to open).
12. **Follow-up and outcomes**
    - 12a Details — when (frequency, maximum length), where (home, primary/secondary care), with whom, how (telephone, virtual, examination, tests); long-term surveillance requirements; postoperative instructions.
    - 12b Intervention adherence and tolerability — how assessed; impact on long-term applicability in practice.
    - 12c Outcomes — expected vs. attained (cite the literature informing expectations); patient-reported measures where appropriate; when recorded.
    - 12d Complications and adverse events — preventive measures taken; describe all events and grade with the **Clavien–Dindo classification**; blood loss, operative time, wound complications, re-exploration; time from intervention to discharge and whether within expectation; 30-day morbidity/mortality where applicable; whether complications were discussed locally (e.g., M&M meetings); state explicitly if there were none.
13. **Discussion**
    - 13a Summary of key findings; rationale for conclusions.
    - 13b Relevant literature and similar published cases.
    - 13c Future implications for clinical practice and guidelines.
    - 13d Take-away lessons — what would be done differently in diagnosis, investigation, or management of future cases.
14. **Strengths and limitations**
    - 14a Key strengths; multidisciplinary or cross-specialty relevance.
    - 14b Weaknesses and limitations, and how challenges were overcome; for novel techniques/devices: contraindications, alternatives, risks, and complications if applied to a larger population.
15. **Patient perspective** — where appropriate, the patient's perspective on the intervention(s), e.g., quotes from a consented and anonymised interview.
16. **Informed consent** — consent for both the original intervention and publication; state the method (verbal, written, digital); if proxy consent (e.g., next of kin after death) or untraceable, explain and document tracing efforts.
17. **Additional information** — author contributions, acknowledgements, conflicts of interest, funding, IRB/ethics approval where required; disclose prior conference presentation and whether the case is under consideration elsewhere.
18. **Clinical images and videos** — pre-, peri-, and post-intervention images (radiological, histopathological, intraoperative), adequately annotated and captioned; link to a narrated operative video where available; all media de-identified.

## Self-check

Same convention as CARE: mark every topic ✅ / ⚠️ / ❌ with a one-line note and deliver the table with the manuscript.
