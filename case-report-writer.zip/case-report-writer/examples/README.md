# examples/

Place **published** case reports here (PDF or Markdown) to serve as format references.

- Only published articles or materials you have the right to share.
- **Never commit identifiable patient data** (names, MRNs, full dates, uncropped DICOM images).
- When you add examples, distill their conventions (section order, abstract structure, citation style, word counts) into `references/journal-style-<name>.md` and link that file from `SKILL.md` Step 1.
